<?php
/**
 * Bootstrap — loaded by every page before anything else.
 * Initialises config, autoloader, session, and language.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Lang.php';
require_once __DIR__ . '/Auth.php';
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/gr_helpers.php';
require_once __DIR__ . '/wh_helpers.php';
require_once __DIR__ . '/UISettings.php';

// ── Session ────────────────────────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => SESSION_LIFETIME,
        'path'     => '/',
        'secure'   => isset($_SERVER['HTTPS']),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_name('buildmart_sess');
    session_start();
}

// ── Language ───────────────────────────────────────────────────────
Lang::init();
date_default_timezone_set(current_timezone());

$scriptPath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$passwordChangeAllowed = [
    '/modules/auth/login.php',
    '/modules/auth/logout.php',
    '/modules/auth/change_password.php',
];

if (Auth::check() && Auth::mustChangePassword() && !in_array($scriptPath, $passwordChangeAllowed, true)) {
    flash_warning(_r('auth_password_change_required'));
    redirect('/modules/auth/change_password.php');
}

// ── Timezone from settings (after DB available) ────────────────────
// (already set in config, fine for now)
