<?php
require_once __DIR__ . '/../../core/bootstrap.php';
require_once __DIR__ . '/../../views/partials/icons.php';
Auth::requireLogin();
Auth::requirePerm('shifts');

$pageTitle   = __('shift_open');
$breadcrumbs = [[__('shift_title'), url('modules/shifts/')], [$pageTitle, null]];

// Check if user already has open shift
$existing = Database::row("SELECT id FROM shifts WHERE user_id=? AND status='open' LIMIT 1", [Auth::id()]);
if ($existing) {
    flash_warning(_r('shift_already_open'));
    redirect('/modules/shifts/');
}

if (is_post()) {
    if (!csrf_verify()) { flash_error(_r('err_csrf')); redirect($_SERVER['REQUEST_URI']); }

    $openingCash = sanitize_float($_POST['opening_cash'] ?? 0);
    $notes       = sanitize($_POST['notes'] ?? '');

    Database::insert(
        "INSERT INTO shifts (user_id, opening_cash, notes, status, opened_at) VALUES (?, ?, ?, 'open', NOW())",
        [Auth::id(), $openingCash, $notes]
    );

    flash_success(_r('shift_opened'));
    redirect('/modules/pos/');
}

include __DIR__ . '/../../views/layouts/header.php';
?>

<div class="page-header"><h1 class="page-heading"><?= __('shift_open') ?></h1></div>
<div style="max-width:440px">
<div class="card">
  <div class="card-body">
    <form method="POST">
      <?= csrf_field() ?>
      <div class="form-group">
        <label class="form-label"><?= __('shift_opening_cash') ?></label>
        <input type="number" name="opening_cash" class="form-control mono" value="0" min="0" step="0.01" style="font-size:20px;padding:12px;text-align:right" autofocus>
        <div class="form-hint">Enter the amount of cash in the register at shift start</div>
      </div>
      <div class="form-group">
        <label class="form-label"><?= __('lbl_notes') ?></label>
        <input type="text" name="notes" class="form-control" placeholder="Optional notes…">
      </div>
      <div style="display:flex;gap:8px">
        <button type="submit" class="btn btn-primary btn-lg btn-block">
          <?= feather_icon('play',18) ?> <?= __('shift_open') ?>
        </button>
      </div>
    </form>
  </div>
</div>
</div>

<?php include __DIR__ . '/../../views/layouts/footer.php'; ?>
<script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
<script>feather.replace();</script>
