<?php
require_once __DIR__ . '/../../core/bootstrap.php';

Auth::requireLogin();
Auth::requirePerm('shifts');

if (!is_ajax() || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_response(['success' => false, 'message' => 'Bad request'], 400);
}

$csrfToken = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if (!hash_equals(csrf_token(), $csrfToken)) {
    json_response(['success' => false, 'message' => _r('err_csrf')], 403);
}

$body = json_decode(file_get_contents('php://input'), true);
if (!is_array($body)) {
    json_response(['success' => false, 'message' => _r('err_validation')], 422);
}

$existing = Database::row("SELECT id FROM shifts WHERE user_id=? AND status='open' LIMIT 1", [Auth::id()]);
if ($existing) {
    json_response([
        'success' => true,
        'message' => _r('shift_already_open'),
        'shift_id' => (int)$existing['id'],
        'already_open' => true,
    ]);
}

$openingCash = max(0, (float)sanitize_float($body['opening_cash'] ?? 0));
$notes = sanitize($body['notes'] ?? '');

$shiftId = Database::insert(
    "INSERT INTO shifts (user_id, opening_cash, notes, status, opened_at) VALUES (?, ?, ?, 'open', NOW())",
    [Auth::id(), $openingCash, $notes]
);

json_response([
    'success' => true,
    'message' => _r('shift_opened'),
    'shift_id' => (int)$shiftId,
]);
