<?php
require_once __DIR__ . '/../../core/bootstrap.php';
require_once __DIR__ . '/../../views/partials/icons.php';
Auth::requireLogin();
Auth::requirePerm('shifts');

$pageTitle   = __('shift_title');
$breadcrumbs = [[$pageTitle, null]];

$openShift = Database::row("SELECT s.*,u.name AS cashier FROM shifts s JOIN users u ON u.id=s.user_id WHERE s.user_id=? AND s.status='open' LIMIT 1", [Auth::id()]);

$page   = max(1,(int)($_GET['page']??1));
$total  = (int)Database::value("SELECT COUNT(*) FROM shifts");
$pg     = paginate($total,$page);
$shifts = Database::all(
    "SELECT s.*,u.name AS cashier FROM shifts s JOIN users u ON u.id=s.user_id ORDER BY s.opened_at DESC LIMIT {$pg['perPage']} OFFSET {$pg['offset']}"
);

include __DIR__ . '/../../views/layouts/header.php';
?>

<div class="page-header">
  <h1 class="page-heading"><?= __('shift_title') ?></h1>
  <div class="page-actions">
    <?php if (!$openShift): ?>
      <a href="<?= url('modules/shifts/open.php') ?>" class="btn btn-primary">
        <?= feather_icon('play',15) ?> <?= __('shift_open') ?>
      </a>
    <?php else: ?>
      <a href="<?= url('modules/shifts/close.php?id='.$openShift['id']) ?>" class="btn btn-danger">
        <?= feather_icon('square',15) ?> <?= __('shift_close') ?>
      </a>
    <?php endif; ?>
  </div>
</div>

<?php if ($openShift): ?>
<div class="card mb-3" style="border-color:var(--success);background:var(--success-dim)">
  <div class="card-body">
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px;text-align:center">
      <?php $info = [
        [__('shift_status_open'),   '<span class="badge badge-success">'.__('shift_status_open').'</span>'],
        [__('shift_opened_at'),     date_fmt($openShift['opened_at'])],
        [__('shift_sales_total'),   money($openShift['total_sales'])],
        [__('shift_tx_count'),      $openShift['transaction_count']],
      ]; ?>
      <?php foreach ($info as [$label,$val]): ?>
      <div>
        <div class="text-muted" style="font-size:11px;text-transform:uppercase;letter-spacing:.05em"><?= $label ?></div>
        <div style="font-size:16px;font-weight:700;margin-top:4px"><?= $val ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<div class="card">
  <div class="table-wrap">
    <table class="table">
      <thead>
        <tr>
          <th><?= __('shift_cashier') ?></th>
          <th><?= __('shift_opened_at') ?></th>
          <th><?= __('shift_closed_at') ?></th>
          <th class="col-num"><?= __('shift_opening_cash') ?></th>
          <th class="col-num"><?= __('shift_sales_total') ?></th>
          <th class="col-num"><?= __('shift_returns_total') ?></th>
          <th class="col-num"><?= __('shift_tx_count') ?></th>
          <th><?= __('lbl_status') ?></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($shifts as $s): ?>
        <tr>
          <td class="fw-600"><?= e($s['cashier']) ?></td>
          <td><?= date_fmt($s['opened_at']) ?></td>
          <td><?= $s['closed_at'] ? date_fmt($s['closed_at']) : '—' ?></td>
          <td class="col-num font-mono"><?= money($s['opening_cash']) ?></td>
          <td class="col-num fw-600"><?= money($s['total_sales']) ?></td>
          <td class="col-num text-danger"><?= $s['total_returns']>0 ? money($s['total_returns']) : '—' ?></td>
          <td class="col-num"><?= $s['transaction_count'] ?></td>
          <td>
            <?php if ($s['status']==='open'): ?>
              <span class="badge badge-success"><?= __('shift_status_open') ?></span>
            <?php else: ?>
              <span class="badge badge-secondary"><?= __('shift_status_closed') ?></span>
              <?php if (!is_null($s['cash_difference'])): ?>
                <span class="badge badge-<?= abs($s['cash_difference'])<0.01?'success':($s['cash_difference']<0?'danger':'warning') ?>" style="margin-top:2px">
                  <?= ($s['cash_difference']>=0?'+':'').money($s['cash_difference'],false) ?> <?= e(currency_symbol()) ?>
                </span>
              <?php endif; ?>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php if ($pg['pages']>1): ?>
  <div class="card-footer flex-between">
    <span class="text-secondary fs-sm"><?= $total ?> <?= __('results') ?></span>
    <div class="pagination">
      <?php for ($i=1;$i<=$pg['pages'];$i++): ?>
        <a href="?page=<?= $i ?>" class="page-link <?= $i==$pg['page']?'active':'' ?>"><?= $i ?></a>
      <?php endfor; ?>
    </div>
  </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../../views/layouts/footer.php'; ?>
<script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
<script>feather.replace();</script>
