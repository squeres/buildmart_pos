<?php
declare(strict_types=1);

require_once __DIR__ . '/../../core/bootstrap.php';

Auth::requireLogin();
Auth::requirePerm('inventory');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/modules/inventory/');
}

if (!csrf_verify()) {
    flash_error(_r('err_csrf'));
    redirect('/modules/inventory/');
}

$id = (int)($_POST['id'] ?? 0);

if ($id <= 0) {
    flash_error('Invalid product.');
    redirect('/modules/inventory/');
}

$product = Database::row(
    "SELECT id, name_en, name_ru, unit, min_stock_qty, min_stock_display_unit_code
     FROM products
     WHERE id=? LIMIT 1",
    [$id]
);

if (!$product) {
    flash_error(_r('err_not_found'));
    redirect('/modules/inventory/');
}

$minStock  = (float)str_replace(',', '.', (string)($_POST['min_stock_qty'] ?? '0'));
$minStockDisplayUnitCode = sanitize((string)($_POST['min_stock_display_unit_code'] ?? ''));

if ($minStock < 0)  $minStock  = 0;
$units = product_units($id, (string)$product['unit']);
$resolvedUnit = product_resolve_unit($units, (string)$product['unit'], $minStockDisplayUnitCode);
$minStockBase = product_qty_to_base_unit($minStock, $units, (string)$product['unit'], (string)$resolvedUnit['unit_code']);

Database::exec(
    "UPDATE products
     SET min_stock_qty = ?, min_stock_display_unit_code = ?
     WHERE id = ?",
    [$minStockBase, (string)$resolvedUnit['unit_code'], $id]
);

flash_success(__('msg_saved'));
redirect('/modules/inventory/');
