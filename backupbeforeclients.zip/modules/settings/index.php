<?php
require_once __DIR__ . '/../../core/bootstrap.php';
require_once __DIR__ . '/../../views/partials/icons.php';
Auth::requireLogin();
Auth::requirePerm('settings');

$pageTitle   = __('set_title');
$breadcrumbs = [[$pageTitle, null]];

$requiredSettings = [
    ['timezone', 'Asia/Almaty', 'Timezone', 'general', 'select'],
    ['currency_code', 'KZT', 'Currency Code', 'general', 'select'],
    ['currency_symbol', '₸', 'Currency Symbol', 'general', 'text'],
];

foreach ($requiredSettings as [$key, $value, $label, $group, $type]) {
    Database::exec(
        "INSERT INTO settings (`key`, value, label, `group`, `type`)
         SELECT ?, ?, ?, ?, ?
         WHERE NOT EXISTS (SELECT 1 FROM settings WHERE `key` = ?)",
        [$key, $value, $label, $group, $type, $key]
    );
}

if (is_post()) {
    if (!csrf_verify()) { flash_error(_r('err_csrf')); redirect($_SERVER['REQUEST_URI']); }

    $keys = Database::all("SELECT `key`,`type` FROM settings");
    $selectedCurrency = normalize_currency_code($_POST['currency_code'] ?? current_currency_code());
    $selectedTimezone = $_POST['timezone'] ?? current_timezone();
    if (!in_array($selectedTimezone, timezone_identifiers_list(), true)) {
        $selectedTimezone = current_timezone();
    }

    foreach ($keys as $row) {
        $k = $row['key'];
        if ($k === 'currency_symbol') {
            $v = currency_symbol($selectedCurrency);
        } elseif ($k === 'currency_code') {
            $v = $selectedCurrency;
        } elseif ($k === 'timezone') {
            $v = $selectedTimezone;
        } else {
            $v = $row['type']==='boolean'
                ? (isset($_POST[$k]) ? '1' : '0')
                : sanitize($_POST[$k] ?? '');
        }
        Database::exec("UPDATE settings SET value=? WHERE `key`=?", [$v, $k]);
    }
    flash_success(_r('set_saved'));
    redirect($_SERVER['REQUEST_URI']);
}

$settings = Database::all("SELECT * FROM settings ORDER BY `group`,`id`");
$grouped  = [];
foreach ($settings as $s) { $grouped[$s['group']][] = $s; }

include __DIR__ . '/../../views/layouts/header.php';
?>

<div class="page-header"><h1 class="page-heading"><?= __('set_title') ?></h1></div>

<form method="POST" style="max-width:720px">
  <?= csrf_field() ?>
  <?php foreach ($grouped as $group => $rows): ?>
  <div class="card mb-3">
    <div class="card-header"><span class="card-title"><?= setting_group_label((string)$group) ?></span></div>
    <div class="card-body">
      <?php foreach ($rows as $s): ?>
      <?php if ($s['key'] === 'currency_symbol') continue; ?>
      <div class="form-group">
        <label class="form-label" for="<?= e($s['key']) ?>"><?= setting_label($s) ?></label>
        <?php if ($s['type']==='boolean'): ?>
          <label class="form-check">
            <input type="checkbox" id="<?= e($s['key']) ?>" name="<?= e($s['key']) ?>" value="1" <?= $s['value']=='1'?'checked':'' ?>>
            <span class="form-check-label"><?= __('lbl_yes') ?></span>
          </label>
        <?php elseif ($s['type']==='textarea'): ?>
          <textarea id="<?= e($s['key']) ?>" name="<?= e($s['key']) ?>" class="form-control" rows="3"><?= e($s['value'] ?? '') ?></textarea>
        <?php elseif ($s['type']==='select' && $s['key']==='default_language'): ?>
          <select id="<?= e($s['key']) ?>" name="<?= e($s['key']) ?>" class="form-control" style="max-width:200px">
            <?php foreach (SUPPORTED_LANGS as $code=>$label): ?>
              <option value="<?= $code ?>" <?= $s['value']===$code?'selected':'' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
        <?php elseif ($s['type']==='select' && $s['key']==='currency_code'): ?>
          <select id="<?= e($s['key']) ?>" name="<?= e($s['key']) ?>" class="form-control" style="max-width:280px">
            <?php foreach (currency_options() as $code => $label): ?>
              <option value="<?= e($code) ?>" <?= normalize_currency_code($s['value']) === $code ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
        <?php elseif ($s['type']==='select' && $s['key']==='timezone'): ?>
          <select id="<?= e($s['key']) ?>" name="<?= e($s['key']) ?>" class="form-control">
            <?php foreach (timezone_options() as $code => $label): ?>
              <option value="<?= e($code) ?>" <?= ($s['value'] ?: current_timezone()) === $code ? 'selected' : '' ?>><?= e($label) ?></option>
            <?php endforeach; ?>
          </select>
        <?php elseif ($s['type']==='number'): ?>
          <input type="number" id="<?= e($s['key']) ?>" name="<?= e($s['key']) ?>" class="form-control mono" value="<?= e($s['value'] ?? '') ?>" style="max-width:150px">
        <?php else: ?>
          <input type="text" id="<?= e($s['key']) ?>" name="<?= e($s['key']) ?>" class="form-control" value="<?= e($s['value'] ?? '') ?>">
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endforeach; ?>

  <button type="submit" class="btn btn-primary btn-lg">
    <?= feather_icon('save',17) ?> <?= __('btn_save') ?>
  </button>
</form>

<?php include __DIR__ . '/../../views/layouts/footer.php'; ?>
<script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
<script>feather.replace();</script>
