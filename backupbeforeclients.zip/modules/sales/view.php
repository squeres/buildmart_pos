<?php
require_once __DIR__ . '/../../core/bootstrap.php';
require_once __DIR__ . '/../../views/partials/icons.php';
Auth::requireLogin();
Auth::requirePerm('sales');

$id   = (int)($_GET['id'] ?? 0);
$sale = Database::row(
    "SELECT s.*,u.name AS cashier,c.name AS customer_name,c.phone AS customer_phone
     FROM sales s JOIN users u ON u.id=s.user_id JOIN customers c ON c.id=s.customer_id WHERE s.id=?",
    [$id]
);
if (!$sale) { flash_error(_r('err_not_found')); redirect('/modules/sales/'); }

$items    = Database::all("SELECT * FROM sale_items WHERE sale_id=?", [$id]);
$payments = Database::all("SELECT * FROM payments WHERE sale_id=?", [$id]);

$pageTitle   = __('pos_receipt_no') . $sale['receipt_no'];
$breadcrumbs = [[__('nav_sales'), url('modules/sales/')], [$pageTitle, null]];

include __DIR__ . '/../../views/layouts/header.php';
?>

<div class="page-header">
  <h1 class="page-heading font-mono"><?= e($sale['receipt_no']) ?></h1>
  <div class="page-actions">
    <a href="<?= url('modules/pos/receipt.php?id='.$id) ?>" target="_blank" class="btn btn-secondary">
      <?= feather_icon('printer',15) ?> <?= __('btn_print') ?>
    </a>
    <?php if ($sale['status']==='completed'): ?>
    <form method="POST" action="<?= url('modules/sales/void.php') ?>" style="display:inline">
      <?= csrf_field() ?>
      <input type="hidden" name="id" value="<?= (int)$id ?>">
      <button type="submit" class="btn btn-danger"
         data-confirm="<?= __('confirm_void') ?>">
        <?= feather_icon('x-circle',15) ?> Void Sale
      </button>
    </form>
    <?php endif; ?>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 320px;gap:16px">

  <!-- Items -->
  <div>
    <div class="card">
      <div class="card-header"><span class="card-title">Items</span></div>
      <div class="table-wrap">
        <table class="table">
          <thead>
            <tr>
              <th><?= __('lbl_name') ?></th>
              <th><?= __('lbl_sku') ?></th>
              <th class="col-num"><?= __('lbl_qty') ?></th>
              <th class="col-num"><?= __('lbl_price') ?></th>
              <th class="col-num"><?= __('lbl_discount') ?></th>
              <th class="col-num"><?= __('lbl_tax') ?></th>
              <th class="col-num"><?= __('lbl_total') ?></th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($items as $it): ?>
            <tr>
              <td class="fw-600"><?= e($it['product_name']) ?></td>
              <td class="font-mono" style="font-size:12px"><?= e($it['product_sku']) ?></td>
              <td class="col-num"><?= number_format((float)$it['qty'],3) ?> <?= unit_label($it['unit']) ?></td>
              <td class="col-num"><?= money($it['unit_price']) ?></td>
              <td class="col-num"><?= $it['discount_amount']>0 ? '−'.money($it['discount_amount']) : '—' ?></td>
              <td class="col-num"><?= $it['tax_amount']>0 ? money($it['tax_amount']) : '—' ?></td>
              <td class="col-num fw-600"><?= money($it['line_total']) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Info panel -->
  <div style="display:flex;flex-direction:column;gap:12px">

    <div class="card">
      <div class="card-header"><span class="card-title">Summary</span></div>
      <div class="card-body">
        <?php $rows = [
          [__('lbl_subtotal'), money($sale['subtotal'])],
          [__('lbl_discount'), $sale['discount_amount']>0 ? '−'.money($sale['discount_amount']) : '—'],
          [__('lbl_tax'),      money($sale['tax_amount'])],
        ]; ?>
        <?php foreach ($rows as [$l,$v]): ?>
        <div class="flex-between mb-1" style="font-size:13px">
          <span class="text-secondary"><?= $l ?></span>
          <span class="font-mono"><?= $v ?></span>
        </div>
        <?php endforeach; ?>
        <div class="flex-between mt-2" style="font-size:20px;font-weight:700;border-top:1px solid var(--border-dim);padding-top:10px">
          <span><?= __('lbl_total') ?></span>
          <span class="font-mono text-amber"><?= money($sale['total']) ?></span>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><span class="card-title">Payment</span></div>
      <div class="card-body">
        <?php foreach ($payments as $pay): ?>
        <div class="flex-between mb-1" style="font-size:13px">
          <span class="text-secondary"><?= __('pos_pay_'.$pay['method']) ?></span>
          <span class="font-mono fw-600"><?= money($pay['amount']) ?></span>
        </div>
        <?php if ($pay['change_given']>0): ?>
        <div class="flex-between" style="font-size:13px">
          <span class="text-secondary"><?= __('pos_change') ?></span>
          <span class="font-mono"><?= money($pay['change_given']) ?></span>
        </div>
        <?php endif; ?>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><span class="card-title">Details</span></div>
      <div class="card-body">
        <?php $info = [
          [__('pos_receipt_no'),   $sale['receipt_no']],
          [__('lbl_date'),         date_fmt($sale['created_at'])],
          [__('shift_cashier'),    $sale['cashier']],
          [__('cust_title'),       $sale['customer_name']],
          [__('lbl_status'),       $sale['status']],
        ]; ?>
        <?php foreach ($info as [$l,$v]): ?>
        <div class="flex-between mb-1" style="font-size:13px">
          <span class="text-muted"><?= e($l) ?></span>
          <span class="fw-600 font-mono"><?= e($v) ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

  </div>
</div>

<?php include __DIR__ . '/../../views/layouts/footer.php'; ?>
<script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
<script>feather.replace();</script>
